# transition matrix
trans = ["AG", "GA", "CT", "TC"]

# transversion matrices
transv1 = ["AT", "TA", "GC", "CG"] 
transv2 = ["AC", "CA", "GT", "TG"] 